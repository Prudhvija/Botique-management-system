<H1><B>Boutique Management System
</h1>
<H1>Installation</H1>
As mentioned, this is a experimental project and is not ready for production. Please use on your own risk.

Required libraries:

.NET Identity
<H1>
Steps of installation</H1>

Import project into Visual Studio (or alternative IDE)
Import and run SQL script attached name Scripts.sql. This will automatically generate database for the project.
Features
Frontend pages - display Products, Orders, Suppliers for Customers and Visitor.
Authentication - a Visitor can become a Customer
Admin Page
CRUD functions for Products and Suppliers, view Orders, view and delete Customer

